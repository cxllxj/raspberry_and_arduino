#include <stdio.h>

int main(int argc, char* argv[])
{
   int i=0x22104101;
   short int si=0x1102;
   //char ch='y';
 
   printf("����si  Address:%x Value:0x%x\n",&si,si);
   printf("-------------------------------\n");
   char* pAddress=(char*)&si;
   for(int j=0;j<=1;j++)
   {
    printf("Address:0x%x Value:0x%2x\n",pAddress,*pAddress);
    pAddress++;
   }
   
   printf("\n");

   printf("����i  Address:%x Value:0x%x\n",&i,i);
   printf("-------------------------------\n");
   pAddress=(char*)&i;
   for(j=0;j<=3;j++)
   {
    printf("Address:0x%x Value:0x%2x\n",pAddress,*pAddress);
    pAddress++;
   }

   return 0;
}