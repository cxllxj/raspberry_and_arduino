#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{
	char ch='a';
    short sht=0x0830;
    int i=0x02110520;
	long lng=-0x02110520;
    float flt=0.5;
	double dbl=-0.25;
		
	printf("Size of char is %d.\n",sizeof(ch)*8);
	printf("Size of short is %d.\n",sizeof(sht)*8);
	printf("Size of int is %d.\n",sizeof(i)*8);
	printf("Size of long is %d.\n",sizeof(lng)*8);
	printf("Size of float is %d.\n",sizeof(flt)*8);
	printf("Size of double is %d.\n",sizeof(dbl)*8);
	
	return 0;
}
