#include <stdio.h>
#include <string.h>

#pragma pack(1)

int main(int argc, char* argv[])
{
	struct A
	{
	   unsigned int    a;
	   unsigned char   b;  
	   unsigned short  c;   
	}sa;
/*
	struct B
	{
	   unsigned char   b;  
	   unsigned int    a;
	   unsigned short  c;   
	}sb;
*/
	sa.a=0x111111111;
	sa.b='a';
	sa.c=0x1234;
/*
	sb.b='b';
	sb.a=0x22222222;
	sb.c=0x4321;
*/
    printf("Size of struct A is %d.\n",sizeof(sa)*8);
	//printf("Size of struct B is %d.\n",sizeof(sb)*8);

	return 0;
}

