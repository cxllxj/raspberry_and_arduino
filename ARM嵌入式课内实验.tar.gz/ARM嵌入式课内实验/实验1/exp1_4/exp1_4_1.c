#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{
	struct A
	{
	   unsigned char   a; 
	   unsigned int    b;
	   unsigned short  c;   
	}sa;

	sa.a='a';
	sa.b=0x111111111;
	sa.c=0x1234;

    printf("Size of struct A is %d.\n",sizeof(sa)*8);

	return 0;
}
