	#include <stdio.h>
	
	void say_hello(void)
	{
		    printf("Hello World!\n");
	}
	
	int main(void)
	{
	    say_hello();
	}