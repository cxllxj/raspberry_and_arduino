#include "exp2_3_1.h"
int main(void)
{
		int i;
		for(i=0;i<3;i++)
		{
         exp2_3_2();
         exp2_3_3();
		}
}
