#include "exp2_3_2.h"
void exp2_3_2()
{
		printf("exp2_3_2\n");
}
