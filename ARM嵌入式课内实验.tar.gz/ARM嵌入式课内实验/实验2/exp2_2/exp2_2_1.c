	#include <stdio.h>
	
	int adder(int upperlimit)
	{
			int i,rlt = 0;
			for(i=1;i<=upperlimit;i++)
				rlt = rlt+i;
			return rlt;	
	}
	
	int main(void)
	{
			int upper,result;
			do
			{
				printf("�������ۼӴ���[4-50]:");
				scanf("%d",&upper);
			}while(upper>50 || upper<4);
			result = adder(upper);
			printf("\n1+2+...+%d���ۼӽ����:%d\n",upper,result);
	}    