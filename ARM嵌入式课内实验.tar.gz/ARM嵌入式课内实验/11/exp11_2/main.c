#include <stdio.h>
#include "swi.h"

unsigned *swi_vec = (unsigned *)0x08;

extern void SWI_Handler(void);

unsigned Install_Handler( unsigned routine, unsigned *vector )
{
    unsigned vec, old_vec;
    vec = (routine - (unsigned)vector - 8) >> 2;
    if (vec & 0xff000000)
    {
        printf("Handler greater than 32MBytes from vector");
    }
    vec = 0xea000000 | vec;     
    old_vec = *vector;
    *vector = vec;
    return (old_vec);
}

int main( void )
{
    int result1, result2;
    struct four_results res_3;

    Install_Handler( (unsigned) SWI_Handler, swi_vec );
    printf("result1=multiply_two(2,4) = %d\n", result1=multiply_two(2,4));
    printf("result2=multiply_two(3,6) = %d\n", result2=multiply_two(3,6));
    printf("add_two(result1,result2) = %d\n", add_two(result1,result2));
    printf("add_multiply_two(2,4,3,6) = %d\n", add_multiply_two(2,4,3,6));
    res_3 = many_operations(12,4,3,1 );
    printf("res_3.a = %d\n", res_3.a );
    printf("res_3.b = %d\n", res_3.b );
    printf("res_3.c = %d\n", res_3.c );
    printf("res_3.d = %d\n", res_3.d );

    return 0;
}
