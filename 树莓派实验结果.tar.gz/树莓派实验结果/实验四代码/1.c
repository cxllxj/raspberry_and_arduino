#include <wiringPi.h>
#include <stdio.h>
int main(void)
{
wiringPiSetup();
pinMode(0,OUTPUT);
return 1;
}
