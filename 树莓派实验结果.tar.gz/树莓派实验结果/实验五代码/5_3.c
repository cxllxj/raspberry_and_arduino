#include <wiringPi.h>
#include <stdio.h>
int main(void)
{
wiringPiSetup();
pinMode(0,OUTPUT);
while(1)
{
	digitalWrite(0, 1);
	delay(200);
	digitalWrite(0, 0);
	delay(200);
}
return 1;
}
