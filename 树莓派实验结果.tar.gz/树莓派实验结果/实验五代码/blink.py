from time import sleep
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(17,GPIO.OUT)
while 1:
     GPIO.output(17,GPIO.HIGH)
     sleep(0.1)
     GPIO.output(17,GPIO.LOW)
     sleep(0.1)

